Folder structure:
    - knn.py: KNN algorithm (Part A.1)
    - item_response.py: Item response algorithm (Part A.2)
    - neural_network.py: Neural network algorithm (Part A.3)
    - ensemble.py: Ensemble algorithm (Part A.4)
    - utils.py: Utility functions
    - modified_IRT.py: Modified IRT algorithm (Part B)
    - modified_utils.py: Helper functions for modified IRT algorithm
